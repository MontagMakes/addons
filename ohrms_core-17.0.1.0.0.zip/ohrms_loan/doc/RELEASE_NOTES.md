## Module <ohrms_loan>

#### 28.11.2023
#### Version 17.0.1.0.0
##### ADD

- Initial commit for Open HRMS Loan Management

##### FIX 

- Updated the Loan Smart button view and added the domain for the tree and form view