## Module <hr_payroll_account_community>

#### 28.11.2023
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Open HRMS Payroll Accounting
