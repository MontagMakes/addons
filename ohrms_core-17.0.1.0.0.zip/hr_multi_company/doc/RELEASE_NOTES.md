## Module <hr_multi_company>

#### 28.11.2023
#### Version 17.0.1.0.0
##### ADD

- Initial commit of Open HRMS Multi-Company
