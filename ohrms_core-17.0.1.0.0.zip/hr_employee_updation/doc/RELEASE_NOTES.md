## Module <hr_employee_updation>

#### 27.02.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Open HRMS Employee Info
