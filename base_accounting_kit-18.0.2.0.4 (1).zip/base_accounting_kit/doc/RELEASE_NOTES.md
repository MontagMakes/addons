## Module <base_accounting_kit>

#### 07.10.2024
#### Version 18.0.1.0.0
#### ADD
- Initial commit for Odoo 18 Full Accounting Kit for Community

#### 22.10.2024
#### Version 18.0.1.0.1
#### UPDT
- Added the reconciliation widget and lock dates.

#### 26.02.2025
#### Version 18.0.1.0.2
#### FIX
- Fixed the Asset creation issue from the vendor bill.

#### 27.03.2025
#### Version 18.0.2.0.2
#### UPDT
- Added the Import Bank Statement feature.

#### 21.04.2025
#### Version 18.0.2.0.4
#### FIX
- Fixed qifparse external dependency (python) issue.
